/**
 * 50_slides.gs（v3: 実測規定・スキップ・アイコン/背景・不透明度対応）
 *
 * テンプレデッキの約束事:
 *  - ノート1行目 {{TPL:xxx}} / テキストスロット {{P1}}〜{{P4}},{{H}},{{M1}}〜{{M3}},{{F1H}}...,{{S1}}〜{{S4}}
 *  - 図解枠: 代替テキストタイトル=IMG または本文 {{IMG}}
 *  - アイコン枠: 代替テキストタイトル=ICON1〜ICON4（複数枠のあるレイアウトは番号必須）
 *  - 背景選定行: 画像を最背面に敷き、紺50%相当のオーバーレイで減光（BG_OVERLAY_ALPHA）
 *  - 工程(kotei): 現在ステップ以外のアイコン/ステップ名を減光（STEP_DIM_ALPHA ≒ 不透明度20%）
 */

function generateSlides_(kouseiSheetId) {
  const cfg = getConfig_();
  const data = readKouseiSheet_(kouseiSheetId);
  const warnings = [];

  const template = SlidesApp.openById(cfg.TEMPLATE_SLIDE_ID);
  const tplMap = {};
  template.getSlides().forEach(function (s) {
    const m = getNotesText_(s).match(/\{\{TPL:([a-z_0-9]+)\}\}/);
    if (m) tplMap[m[1]] = s;
  });

  const pres = SlidesApp.create('【スライド】' + data.name);
  DriveApp.getFileById(pres.getId()).moveTo(DriveApp.getFolderById(cfg.OUTPUT_FOLDER_ID));
  const defaultSlide = pres.getSlides()[0];

  const zukaiFolder = resolveAssetsFolder_(cfg, data);
  const idx = {
    ICON_P: buildAssetIndex_(cfg, 'ICON_P'),
    ICON_W: buildAssetIndex_(cfg, 'ICON_W'),
    BG: buildAssetIndex_(cfg, 'BG'),
    SELECT: buildAssetIndex_(cfg, 'SELECT')
  };
  const targets = designTargets_();
  const blobCache = {};

  const defs = rowDefs_();
  defs.forEach(function (def) {
    const row = data.rows[def.no];
    if (!row) { warnings.push('No.' + def.no + ' が構成シートにありません'); return; }
    const tplSlide = tplMap[def.layout];
    if (!tplSlide) { warnings.push('テンプレにレイアウトなし: ' + def.layout + '（No.' + def.no + '）'); return; }
    const slide = pres.appendSlide(tplSlide, SlidesApp.SlideLinkingMode.NOT_LINKED);

    // スキップ行（斜線・データなし）: テンプレ文言のまま「スキップ」設定
    if (isSkipRow_(def, row)) {
      fillSkip_(slide, def);
      setNotesText_(slide, '');
      try { slide.setSkipped(true); } catch (e) { warnings.push('No.' + def.no + ' スキップ設定失敗: ' + e); }
      return;
    }

    fillSlots_(slide, def, row, data, warnings);
    setNotesText_(slide, row.daihon || '');
    if (def.img) insertZukaiImage_(slide, def, row, zukaiFolder, warnings);
    applyIcons_(slide, def, data, idx, warnings);
    applyBg_(slide, def, row, targets, idx, blobCache, warnings);
  });

  if (defaultSlide && pres.getSlides().length > 1) defaultSlide.remove();
  if (warnings.length > 0) Logger.log('スライド生成警告:\n' + warnings.join('\n'));
  return { pres: pres, warnings: warnings };
}

// ============================================================
// スキップ（斜線）
// ============================================================
function isSkipRow_(def, row) {
  if (!SKIP_ROWS[def.no]) return false;
  const k = String(row.kousei || '').trim();
  return k === '' || k.indexOf('斜線') !== -1;
}
function fillSkip_(slide, def) {
  const parts = String(SKIP_ROWS[def.no]).split('\n');
  rep_(slide, 'P1', parts[0] || '');
  rep_(slide, 'P2', parts.slice(1).join('\n'));
  rep_(slide, 'P3', ''); rep_(slide, 'P4', ''); rep_(slide, 'H', '');
}

// ============================================================
// テキストスロット
// ============================================================
function cleanText_(t) {
  return String(t || '').replace(/図解（[^）]*）/g, '').replace(/^No\.92の金額に赤の二重線を引く。$/, '').trim();
}
function lines_(t) {
  return cleanText_(t).split('\n').map(function (l) { return l.trim(); }).filter(function (l) { return l !== ''; });
}
function rep_(slide, ph, val) { slide.replaceAllText('{{' + ph + '}}', val || ''); }
function rowLines_(data, no) {
  const r = data.rows[no];
  return r ? lines_(r.kouseiResolved) : [];
}

/** 事例After行 → 対応するBefore行 */
const CASE_PAIR = { 46: 45, 74: 73, 76: 75 };

function fillSlots_(slide, def, row, data, warnings) {
  const L = LAYOUT;
  const parts = lines_(row.kouseiResolved);
  switch (def.layout) {
    case L.COVER:
      break;
    case L.NARRATIVE:
      if (parts.length >= 2) { rep_(slide, 'P1', parts[0]); rep_(slide, 'P2', parts.slice(1).join('\n')); }
      else { rep_(slide, 'P1', ''); rep_(slide, 'P2', parts[0] || ''); }
      break;
    case L.CASE: { // タイトル/社長名/業種役職 はBefore行を単一ソースに（After行へ自動反映）
      const srcNo = CASE_PAIR[def.no] || def.no;
      const head = rowLines_(data, srcNo);
      const title = head[0] || '';
      const role = head[1] || '';
      rep_(slide, 'P1', title);
      rep_(slide, 'P3', title.replace(/の事例$/, ''));
      rep_(slide, 'P4', role);
      const body = CASE_PAIR[def.no] ? parts : parts.slice(2);
      rep_(slide, 'P2', body.join('\n'));
      if (!CASE_PAIR[def.no] && parts.length < 3) warnings.push('No.' + def.no + ' 事例の行数不足（タイトル/業種役職/本文 の3行以上が必要）');
      break;
    }
    case L.SERVICE:
    case L.CHALLENGE:
    case L.IMPACT:
    case L.PRICE:
      rep_(slide, 'P1', parts[0] || '');
      rep_(slide, 'P2', parts.slice(1).join('\n'));
      break;
    case L.MERIT_INTRO:
    case L.POINT_INTRO:
      rep_(slide, 'P1', parts.join('\n'));
      break;
    case L.MERIT: {
      rep_(slide, 'H', (rowLines_(data, 41)[0] || ''));
      const cur = def.no - 42;
      for (let i = 0; i <= 2; i++) {
        const src = i < cur ? (rowLines_(data, 42 + i)[0] || '') : (i === cur ? (parts[0] || '') : '');
        rep_(slide, 'M' + (i + 1), src);
      }
      rep_(slide, 'P2', parts.slice(1).join('\n'));
      break;
    }
    case L.POINT1:
      rep_(slide, 'H', (rowLines_(data, 50)[0] || ''));
      rep_(slide, 'M1', parts.join('\n'));
      break;
    case L.POINT2:
      rep_(slide, 'H', (rowLines_(data, 50)[0] || ''));
      rep_(slide, 'M1', rowLines_(data, 51).join('\n'));
      rep_(slide, 'M2', parts.join('\n'));
      break;
    case L.FEATURES: {
      const srcParts = def.km === 'REF' ? rowLines_(data, def.kRef) : parts;
      rep_(slide, 'P1', srcParts[0] || '');
      for (let i = 1; i <= 3; i++) {
        const seg = (srcParts[i] || '').split(/[／/|]/);
        rep_(slide, 'F' + i + 'H', (seg[0] || '').trim());
        rep_(slide, 'F' + i + 'B', (seg.slice(1).join('／') || '').trim());
        if (srcParts[i] && seg.length < 2) warnings.push('No.' + def.no + ' 特徴' + i + ' に区切り「／」がありません');
      }
      break;
    }
    case L.STEPS: {
      rep_(slide, 'P1', parts[0] || '');
      rep_(slide, 'P2', parts[1] || '');
      for (let i = 1; i <= 4; i++) rep_(slide, 'S' + i, parts[i + 1] || '');
      break;
    }
    case L.KOTEI: { // ステップ名はNo.86の3〜6行目から自動反映
      const steps = rowLines_(data, 86).slice(2);
      for (let i = 1; i <= 4; i++) rep_(slide, 'S' + i, steps[i - 1] || '');
      break;
    }
    case L.INVEST:
    case L.STRIKE: {
      const src = def.layout === L.STRIKE ? rowLines_(data, 92) : parts;
      rep_(slide, 'P1', src[0] || '');
      rep_(slide, 'P2', src[1] || '');
      rep_(slide, 'P3', src.slice(2).join('\n'));
      if (def.layout === L.STRIKE && src[1]) strikeAmount_(slide, src[1], warnings);
      break;
    }
    default: // QUESTION / IDEAL / TEXT55 / RINEN / DIAGRAM / DIAGRAM40 / PROFILE / statics
      rep_(slide, 'P1', parts.join('\n'));
  }
}

function strikeAmount_(slide, amount, warnings) {
  try {
    slide.getShapes().forEach(function (s) {
      if (!s.getText) return;
      const tr = s.getText();
      if (tr.asString().indexOf(amount) !== -1) {
        tr.getTextStyle().setStrikethrough(true).setForegroundColor('#DD4031'); // 実測: 赤 #DD4031
      }
    });
  } catch (e) { warnings.push('No.95 二重線の適用に失敗: ' + e); }
}

// ============================================================
// ノート
// ============================================================
function getNotesText_(slide) {
  const sh = slide.getNotesPage().getSpeakerNotesShape();
  return sh ? sh.getText().asString() : '';
}
function setNotesText_(slide, text) {
  const sh = slide.getNotesPage().getSpeakerNotesShape();
  if (sh) sh.getText().setText(text);
}

// ============================================================
// 素材フォルダ解決・索引
// ============================================================
function resolveAssetsFolder_(cfg, data) {
  if (data.assetsFolderId) {
    try { return DriveApp.getFolderById(data.assetsFolderId); } catch (e) { /* fallthrough */ }
  }
  const root = DriveApp.getFolderById(cfg.ASSETS_FOLDER_ID);
  const sub = root.getFoldersByName(data.name);
  return sub.hasNext() ? sub.next() : root;
}

/** 用途キー(ICON_P/ICON_W/BG/SELECT) → フォルダ（プロパティ → 素材ルート同名 → 既定ID） */
function resolveNamedFolder_(cfg, key) {
  const pid = PropertiesService.getScriptProperties().getProperty(ASSET_PROP_KEYS[key]);
  if (pid) { try { return DriveApp.getFolderById(pid); } catch (e) { /* next */ } }
  try {
    const it = DriveApp.getFolderById(cfg.ASSETS_FOLDER_ID).getFoldersByName(ASSET_SUB[key]);
    if (it.hasNext()) return it.next();
  } catch (e) { /* next */ }
  try { return DriveApp.getFolderById(DEFAULT_ASSET_IDS[key]); } catch (e) { return null; }
}

function buildAssetIndex_(cfg, key) {
  const index = {};
  const folder = resolveNamedFolder_(cfg, key);
  if (!folder) return index;
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    if (f.getMimeType().indexOf('image/') === 0) index[normalizeKey_(f.getName())] = f;
  }
  return index;
}

function lookupAsset_(index, name) {
  if (!name) return null;
  const key = normalizeKey_(name);
  if (index[key]) return index[key];
  const keys = Object.keys(index);
  for (let i = 0; i < keys.length; i++) {
    if (keys[i].indexOf(key) !== -1 || key.indexOf(keys[i]) !== -1) return index[keys[i]];
  }
  return null;
}

function normalizeKey_(s) {
  const circled = { '①': '1', '②': '2', '③': '3', '④': '4', '⑤': '5', '⑥': '6' };
  return String(s)
    .replace(/\.[A-Za-z0-9]+$/, '')
    .replace(/[①-⑥]/g, function (c) { return circled[c]; })
    .replace(/[（(]/g, '(').replace(/[）)]/g, ')')
    .replace(/[\s\u3000_-]+/g, '')
    .toLowerCase();
}

// ============================================================
// 図解画像
// ============================================================
function insertZukaiImage_(slide, def, row, folder, warnings) {
  let keyword = def.img;
  const m = String(row.kouseiResolved || '').match(/図解（([^）]+)）/);
  if (m) keyword = m[1];
  const partialOnly = def.img === '*プロフ';
  const key = normalizeKey_(partialOnly ? 'プロフ' : keyword);

  let exact = null, partial = null;
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    if (f.getMimeType().indexOf('image/') !== 0) continue;
    const nk = normalizeKey_(f.getName());
    if (!partialOnly && nk === key) { exact = f; break; }
    if (nk.indexOf(key) !== -1 && !partial) partial = f;
  }
  const file = exact || partial;
  if (!file) { warnings.push('No.' + def.no + ' 図解未発見: ' + keyword + '（枠を残しました）'); return; }
  const ph = findPlaceholder_(slide, 'IMG', '{{IMG}}');
  if (!ph) { warnings.push('No.' + def.no + ' テンプレにIMG枠がありません'); return; }
  fitImageInto_(slide, ph, file);
}

// ============================================================
// アイコン（複数枠・出典フォルダ別・工程の減光）
// ============================================================
function applyIcons_(slide, def, data, idx, warnings) {
  const L = LAYOUT;
  const label = 'No.' + def.no;

  function put(n, name, index) {
    const ph = findPlaceholder_(slide, 'ICON' + n, null);
    if (!ph) return null;
    const nm = (name || '').trim();
    if (!nm) { ph.remove(); return null; }
    const file = lookupAsset_(index, nm);
    if (!file) { warnings.push(label + ' アイコン未発見: ' + nm + '（枠を削除）'); ph.remove(); return null; }
    return fitImageInto_(slide, ph, file);
  }

  switch (def.layout) {
    case L.MERIT: { // 累積開示: 開示済み分のみアイコン、残りは枠削除→数字円
      const cur = def.no - 42;
      for (let i = 0; i <= 2; i++) {
        put(i + 1, i <= cur ? (data.rows[42 + i] || {}).icon : '', idx.ICON_P);
      }
      break;
    }
    case L.POINT1:
      put(1, (data.rows[51] || {}).icon, idx.ICON_P);
      break;
    case L.POINT2:
      put(1, (data.rows[51] || {}).icon, idx.ICON_P);
      put(2, (data.rows[53] || {}).icon, idx.ICON_P);
      break;
    case L.FEATURES: { // No.80のF列「名1／名2／名3」→ 白アイコン×3（82/84へも同じものを再掲）
      const names = String((data.rows[80] || {}).icon || '').split(/[／/|]/);
      for (let i = 1; i <= 3; i++) put(i, (names[i - 1] || '').trim(), idx.ICON_W);
      break;
    }
    case L.STEPS:
    case L.KOTEI: { // アイコンはNo.87-90のF列から。工程スライドは非現在ステップを減光
      const imgs = [];
      for (let i = 1; i <= 4; i++) imgs.push(put(i, (data.rows[86 + i] || {}).icon, idx.ICON_P));
      if (def.layout === L.KOTEI) dimSteps_(slide, def.no - 87, imgs);
      break;
    }
    default:
      break; // アイコン枠なし
  }
}

/** 工程スライド: 現在ステップ以外のアイコンとステップ名に紺の半透明を被せて減光（実測: 不透明度20%相当） */
function dimSteps_(slide, currentIdx, imgs) {
  const xs = [40, 212, 384, 556];
  for (let i = 0; i < 4; i++) {
    if (i === currentIdx) continue;
    const l = imgs[i] ? imgs[i].getLeft() - 6 : xs[i] + 34;
    const t = imgs[i] ? imgs[i].getTop() - 6 : 20;
    const w = imgs[i] ? imgs[i].getWidth() + 12 : 84;
    const h = imgs[i] ? imgs[i].getHeight() + 108 : 184; // ステップ名まで覆う
    const ov = slide.insertShape(SlidesApp.ShapeType.RECTANGLE, l, t, w, h);
    ov.getFill().setSolidFill('#FFFFFF', STEP_DIM_ALPHA); // 明色テーマ: 白80%で不透明度20%相当を再現
    ov.getBorder().setTransparent();
  }
}

// ============================================================
// 背景（選定行はみ: 画像を最背面+紺オーバーレイで減光）
// ============================================================
function applyBg_(slide, def, row, targets, idx, blobCache, warnings) {
  let index = null;
  if (targets.bg.indexOf(def.no) !== -1) index = idx.BG;
  else if (targets.select.indexOf(def.no) !== -1) index = idx.SELECT;
  if (!index) return; // 固定背景・背景なしの行

  const name = (row.bg || '').trim();
  if (!name) return; // 未指定はテンプレ既定
  const file = lookupAsset_(index, name);
  if (!file) { warnings.push('No.' + def.no + ' 背景未発見: ' + name); return; }
  try {
    if (!blobCache[file.getId()]) blobCache[file.getId()] = file.getBlob();
    const W = slide.getWidth ? slide.getWidth() : 720;
    const img = slide.insertImage(blobCache[file.getId()]);
    const scale = Math.max(720 / img.getWidth(), 450 / img.getHeight());
    img.setWidth(img.getWidth() * scale).setHeight(img.getHeight() * scale).setLeft(0).setTop(0);
    const ov = slide.insertShape(SlidesApp.ShapeType.RECTANGLE, 0, 0, 720, 450);
    ov.getFill().setSolidFill('#FFFFFF', BG_OVERLAY_ALPHA); // 明色テーマ: 画像を白で減光（実測25〜85%の近似）
    ov.getBorder().setTransparent();
    ov.sendToBack();
    img.sendToBack(); // 画像を最背面、その上に減光オーバーレイ
  } catch (e) { warnings.push('No.' + def.no + ' 背景適用失敗: ' + e); }
}

// ============================================================
// プレースホルダ共逛
// ============================================================
function findPlaceholder_(slide, title, literal) {
  return slide.getShapes().filter(function (s) {
    try {
      if (s.getTitle && s.getTitle() === title) return true;
      if (literal && s.getText && s.getText().asString().trim() === literal) return true;
    } catch (e) { /* テキストなし */ }
    return false;
  })[0] || null;
}

function fitImageInto_(slide, ph, file) {
  const bw = ph.getWidth(), bh = ph.getHeight(), bl = ph.getLeft(), bt = ph.getTop();
  const img = slide.insertImage(file.getBlob());
  const iw = img.getWidth(), ih = img.getHeight();
  const scale = Math.min(bw / iw, bh / ih);
  const w = iw * scale, h = ih * scale;
  img.setWidth(w).setHeight(h).setLeft(bl + (bw - w) / 2).setTop(bt + (bh - h) / 2);
  ph.remove();
  return img;
}
