/**
 * 00_config.gs（APIレス版・実測規定反映）
 * スクリプトプロパティ・106行定義テーブル・レイアウト定義・文字数規定
 * ※ フォントサイズ・字数はサンプル1,2の全106枚×2の実測値
 *   （詳細は「文字数・フォントサイズ規定書.md」参照。本ファイルが単一ソース）
 */

function getConfig_() {
  const p = PropertiesService.getScriptProperties();
  const req = ['INPUT_FOLDER_ID', 'OUTPUT_FOLDER_ID', 'TEMPLATE_SLIDE_ID', 'ASSETS_FOLDER_ID', 'MGMT_SHEET_ID'];
  const cfg = {};
  req.forEach(function (k) {
    cfg[k] = p.getProperty(k);
    if (!cfg[k]) throw new Error('スクリプトプロパティ未設定: ' + k + '（bootstrapAll() を実行すると自動設定されます）');
  });
  return cfg;
}

// ============================================================
// タブ名・素材サブフォルダ名
// ============================================================
const TABS = { SETTINGS: '設定', INTRO: 'イントロ', PROBLEM: '問題教育', STORY: 'ストーリー', OFFER: 'オファー' };
const HEARING_TABS = { OFFER: '【オファー記入用】', PROBLEM: '【問題教育の記入用】', STORY: '【ストーリーの記入用】' };
const ASSET_SUB = { ICON_P: 'アイコン（紫）', ICON_W: 'アイコン（白）', BG: '背景画像', SELECT: '選択画像' }; // 全案件共通

// ユーザー指定の既定フォルダID（スクリプトプロパティ ICON_PURPLE_FOLDER_ID 等で上書き可 →
// 未設定なら素材ルート直下の同名サブフォルダ → それも無ければこの既定ID）
const DEFAULT_ASSET_IDS = {
  ICON_P: '1cbcsXZmF8BUt9LSoFC9_w7D3mHrvfobm',
  ICON_W: '1A0yNQC8MWu3_iJgN_WmClrEJ413VDpzi',
  BG: '1Cz-d4w3t3Iv4lloUVcg74m65JxZ1j5Ot',
  SELECT: '1jbtXYqdLM_5wDEkZ7agQ-GO0nGY0izaS'
};
const ASSET_PROP_KEYS = { ICON_P: 'ICON_PURPLE_FOLDER_ID', ICON_W: 'ICON_WHITE_FOLDER_ID', BG: 'BG_FOLDER_ID', SELECT: 'SELECT_BG_FOLDER_ID' };

/** アイコン/背景の選定対象行（ユーザー指定） */
function designTargets_() {
  return {
    iconPurple: [42,43,44,51,53,87,88,89,90],   // 円内・工程アイコン
    iconWhite: [80],                              // 特長カード上の白アイコン×3（／区切り。82,84へ自動再掲）
    bg: range_(3,5).concat(range_(8,10), range_(12,31), range_(57,70), [93,94,100]), // 背景画像フォルダ
    select: [72]                                  // 選択画像フォルダ
  };
}

/** 斜線（該当なし）でスキップ可能な行 → スキップ時にテンプレへ入れる文言 */
const SKIP_ROWS = { 99: '特典②', 104: '分割払いも可能です。\n24回払いなら\n◯万円／月' };

/** 背景画像適用時の紺オーバーレイ透過（サンプル実測: 画像25〜85%減光+紺50%帯 の近似） */
const BG_OVERLAY_ALPHA = 0.55;
const STEP_DIM_ALPHA = 0.8; // 工程の非現在ステップ（実測: アイコン不透明度20%）

// ============================================================
// レイアウトタグ（テンプレデッキのノート1行目 {{TPL:xxx}} と対応）
// フォント規定は 05_bootstrap.gs のレイアウト生成が本規定どおりに実装する
// ============================================================
const LAYOUT = {
  COVER: 'cover',            // No.1 全面サムネイル
  QUESTION: 'question',      // 問いかけ 45pt
  IDEAL: 'ideal',            // 理想/お悩み 45pt（1行25字 or 2行各14字）+ICON
  NARRATIVE: 'narrative',    // リード30pt+メイン55pt +ICON
  TEXT55: 'text55',          // 大見出し 55pt 1-2行 +ICON
  DIAGRAM: 'diagram',        // 見出し20pt+図解IMG
  DIAGRAM40: 'diagram40',    // 見出し40pt+図解IMG（特徴詳細・特典）
  CASE: 'case',              // 事例 名前30pt+本文20pt+図解IMG
  SERVICE: 'service',        // サービス名45pt+概要15pt+モックアップIMG
  MERIT_INTRO: 'merit_intro',// No.41 帯20pt+数字円×3
  MERIT: 'merit',            // No.42-44 帯(No.41再掲)+円下見出し19pt+説明20pt
  POINT_INTRO: 'point_intro',// No.50 帯20pt+数字大円×2
  POINT1: 'point1',          // No.51 帯(No.50再掲)+円内30pt×1
  POINT2: 'point2',          // No.53 帯(No.50再掲)+円内30pt×2（①はNo.51再掲）
  CHALLENGE: 'challenge',    // No.55 タイトル55pt+箇条書き30pt
  FEATURES: 'features',      // No.80/82/84 サービス名45pt+カード3枚(見出し14pt/補足11pt)
  STEPS: 'steps',            // No.86 36pt+20pt+ステップ名12pt×4+アイコン72pt×4
  KOTEI: 'kotei',            // No.87-90 上部ステップ帯(アイコン72pt・非現在20%)+図解IMG
  RINEN: 'rinen',            // No.78/103 45pt+上下固定画像帯
  IMPACT: 'impact',          // No.77/91 70pt+40pt
  PRICE: 'price',            // No.96/102 45pt+価格行40pt
  INVEST: 'invest',          // No.92 30pt+金額80pt+30pt
  STRIKE: 'strike',          // No.95 invest構成+金額行に赤二重線
  PROFILE: 'profile',        // No.6
  S_ZOOM: 'static_zoom', S_MEIGEN: 'static_meigen', S_BYAF: 'static_byaf', S_OREI: 'static_orei'
};

// ============================================================
// 固定台本
// ============================================================
const FIXED_DAIHON = {
  2: 'では最初に、\n皆さん、今から1か月後のことを少しだけ想像してみてください。',
  7: '例えば、皆さん経営していてこんなお悩みはありませんか？\nもし、当てはまるものがあれば、挙手🖐️マークでリアクションしていただけると嬉しいです！',
  33: 'なぜ、このような問題が起こるのでしょうか？',
  38: 'では、どうすればいいのか？',
  49: 'では、どうすればいいのか？',
  97: 'さらに、本日ZOOM終了までにお申し込みいただける方には、追加特典をご用意しております。',
  101: '経営の神様ピーター・ドラッカーも、\n今、上手くいっているから、今の仕事のやり方だけを続ける経営者は必然的に失敗する。\nという名言があるように。\n新しい仕事のやり方、営業のやり方にチャレンジする皆様の背中を押すために。',
  105: 'どちらでも構いません。\n大切なのは、ご自身の意思で決断することです。',
  106: '以上で、\n本日のご案内はすべてとなります。\n\n最後までご視聴いただき、\n本当にありがとうございました。'
};

// ============================================================
// 文字数規定（実測ベース）: no範囲 → {fmt: プロンプト用書式説明, maxLine: 1行最大字数, maxLines: 最大行数}
// バリデーションは図解タグ行を除いた各行に適用（超過は警告・停止しない）
// ============================================================
function kouseiSpec_() {
  const S = {};
  function set(nos, fmt, maxLine, maxLines) {
    nos.forEach(function (no) { S[no] = { fmt: fmt, maxLine: maxLine, maxLines: maxLines }; });
  }
  set([3,4,5,8,9,10,93,94,100], '45pt。15字以内なら1行（最大25字）、16字以上は意味の切れ目で2行に分割し各行14字以内。', 25, 2);
  set([11], '45pt×2行。「ある〇〇会社の経営者」＋「〇〇社長の話」。各行12字以内。', 12, 2);
  set(range_(12,32).concat(range_(57,72)), '1行目=リード（状況説明・17字以内・省略可）、2行目以降=メイン（強調・各17字以内・最大2行）。', 17, 3);
  set([34,39,47,48], '大見出し。1〜2行・各行17字以内。', 17, 2);
  set([78,103], '理念。45pt・2行・各行12字以内（上下の実績画像帯は固定）。', 12, 2);
  set([35,36,37,40,52,54], '図解の見出し1行・20字以内＋図解タグ。', 20, 1);
  set([87,88,89,90], '図解タグのみ（見出し不要。上部のステップ帯はNo.86から自動反映）。', 20, 1);
  set([45,73,75], '1行目=「〇〇社長の事例」（9字以内）、2行目=「業種 役職」（例: IT会社 代表取締役・14字以内）、3行目以降=要約（1〜2行・各27字以内）＋図解タグ。', 27, 4);
  set([46,74,76], '要約のみ（1〜2行・各27字以内）＋図解タグ。社長名・業種役職は直前のBefore行から自動反映される。', 27, 2);
  set([56,79], '1行目=サービス名（15字以内）、2〜3行目=概要文（各30字以内）＋図解タグ。', 30, 3);
  set([41], '「（動作）することで得られる3つのメリット」形式・19字以内・1行。', 19, 1);
  set([42,43,44], '1行目=円内見出し（体言止め・9字以内）、2行目以降=説明文（1〜2行・計36字以内・各行23字以内）。', 23, 3);
  set([50], '「正しい〇〇のポイント」形式・14字以内・1行。', 14, 1);
  set([51,53], '円内テキスト。1行なら16字以内、2行に分ける場合は各8字以内。', 16, 2);
  set([55], '1行目=「よくある課題」、2〜4行目=「・」＋課題（・を除き各18字以内）×3点。', 19, 4);
  set([80], '1行目=サービス名（15字以内）、2〜4行目=「見出し／補足」（全角スラッシュ区切り。見出し11字以内・補足25字以内）×3。', 40, 4);
  set([81,83,85,98,99], '「特徴① 〇〇」等の見出し1行・13字以内＋図解タグ。', 13, 1);
  set([86], '1行目=サービス名（12字以内）、2行目=「導入フローは4ステップ」等（19字以内）、3〜6行目=ステップ名（各8字以内）×4。', 19, 6);
  set([77,91], '1行目=数字入りインパクト行（10字以内・70pt）、2行目=補足（11字以内・40pt）。', 11, 2);
  set([92,95], '1行目=前段（17字以内）、2行目=金額のみ（9字以内・80pt表示）、3行目=後段（17字以内）。', 17, 3);
  set([96,102], '1行目=サービス名（15字以内）、2行目以降=「プラン名 金額」（各12字以内）。', 15, 6);
  set([104], '3行・各10字以内（例:「分割払いも可能です。」「24回払いなら」「〇万円／月」）。', 10, 3);
  set([6], '1行目=図解タグ、2行目=会社名・肩書、3行目=氏名、4行目以降=プロフィール文。', 200, 12);
  set([1], '「図解（サムネイル）」固定。', 30, 1);
  return S;
}
function range_(a, b) { const r = []; for (let i = a; i <= b; i++) r.push(i); return r; }

// ============================================================
// 106行定義テーブル
//  km: GEN/FIX/REF/EMPTY, dm: GEN/FIX, layout, img: 図解キーワード, icon: アイコン枠あり
// ============================================================
function rowDefs_() {
  const R = [];
  function d(no, tab, label, sub, km, kFix, kRef, dm, layout, img, icon) {
    R.push({ no: no, tab: tab, label: label, sub: sub || '', km: km, kFix: kFix || '', kRef: kRef || 0, dm: dm, layout: layout, img: img || null, icon: !!icon });
  }
  const T = TABS, L = LAYOUT;
  d(1, T.INTRO, '表紙（タイトル）', '', 'FIX', '図解（サムネイル）', 0, 'GEN', L.COVER, 'サムネイル');
  d(2, T.INTRO, '問いかけ', '', 'FIX', 'もし、こうなったら？', 0, 'FIX', L.QUESTION, null);
  d(3, T.INTRO, '理想①②③', '', 'GEN', '', 0, 'GEN', L.IDEAL, null);
  d(4, T.INTRO, '', '', 'GEN', '', 0, 'GEN', L.IDEAL, null);
  d(5, T.INTRO, '', '', 'GEN', '', 0, 'GEN', L.IDEAL, null);
  d(6, T.INTRO, '講師紹介', '', 'GEN', '', 0, 'GEN', L.PROFILE, '*プロフ');
  d(7, T.PROBLEM, '問いかけ', '', 'FIX', '例えば、こんなお悩みありませんか？', 0, 'FIX', L.QUESTION, null);
  d(8, T.PROBLEM, 'お悩み①②③', '', 'GEN', '', 0, 'GEN', L.IDEAL, null);
  d(9, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.IDEAL, null);
  d(10, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.IDEAL, null);
  d(11, T.PROBLEM, 'ある経営者の話', '', 'GEN', '', 0, 'GEN', L.IDEAL, null);
  d(12, T.PROBLEM, '以前の状況', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(13, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(14, T.PROBLEM, '課題のきっかけ', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(15, T.PROBLEM, '引き起こる課題（一次）', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(16, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(17, T.PROBLEM, '引き起こる課題（二次）', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(18, T.PROBLEM, '連鎖・拡大', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(19, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(20, T.PROBLEM, '経営リスクの認識', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(21, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(22, T.PROBLEM, '解決への決断', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(23, T.PROBLEM, '取り組み①の内容', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(24, T.PROBLEM, '取り組み①のエピソード', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(25, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(26, T.PROBLEM, '取り組み①の結果', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(27, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(28, T.PROBLEM, '取り組み②の内容', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(29, T.PROBLEM, '取り組み②のエピソード', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(30, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(31, T.PROBLEM, '取り組み②の結果', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(32, T.PROBLEM, '経営者の嘆き', '', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(33, T.PROBLEM, '問いかけ', '', 'FIX', 'なぜ、このような問題が起こるのか？', 0, 'FIX', L.QUESTION, null);
  d(34, T.PROBLEM, '旧ビリーフ', '', 'GEN', '', 0, 'GEN', L.TEXT55, null);
  d(35, T.PROBLEM, '旧ビリーフの定義', '', 'GEN', '', 0, 'GEN', L.DIAGRAM, '図解1');
  d(36, T.PROBLEM, 'デメリット', '', 'GEN', '', 0, 'GEN', L.DIAGRAM, '図解2');
  d(37, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.DIAGRAM, '図解3');
  d(38, T.PROBLEM, '問いかけ', '', 'FIX', 'では、どうすれば？', 0, 'FIX', L.QUESTION, null);
  d(39, T.PROBLEM, '新ビリーフ', '', 'GEN', '', 0, 'GEN', L.TEXT55, null);
  d(40, T.PROBLEM, '新ビリーフの定義', '', 'GEN', '', 0, 'GEN', L.DIAGRAM, '図解4');
  d(41, T.PROBLEM, 'メリット', '', 'GEN', '', 0, 'GEN', L.MERIT_INTRO, null);
  d(42, T.PROBLEM, 'メリット①', '', 'GEN', '', 0, 'GEN', L.MERIT, null, true);
  d(43, T.PROBLEM, 'メリット②', '', 'GEN', '', 0, 'GEN', L.MERIT, null, true);
  d(44, T.PROBLEM, 'メリット③', '', 'GEN', '', 0, 'GEN', L.MERIT, null, true);
  d(45, T.PROBLEM, '事例（Before）', '', 'GEN', '', 0, 'GEN', L.CASE, '事例①（before）');
  d(46, T.PROBLEM, '事例（After）', '', 'GEN', '', 0, 'GEN', L.CASE, '事例①（after）');
  d(47, T.PROBLEM, 'よくある間違い', '', 'GEN', '', 0, 'GEN', L.TEXT55, null);
  d(48, T.PROBLEM, '', '', 'GEN', '', 0, 'GEN', L.TEXT55, null);
  d(49, T.PROBLEM, '問いかけ', '', 'FIX', 'では、どうすればいいのか？', 0, 'FIX', L.QUESTION, null);
  d(50, T.PROBLEM, '正しい行動のポイント', '', 'GEN', '', 0, 'GEN', L.POINT_INTRO, null);
  d(51, T.PROBLEM, 'ポイント①', '', 'GEN', '', 0, 'GEN', L.POINT1, null, true);
  d(52, T.PROBLEM, 'ポイント①の解説', '', 'GEN', '', 0, 'GEN', L.DIAGRAM, '図解5');
  d(53, T.PROBLEM, 'ポイント②', '', 'GEN', '', 0, 'GEN', L.POINT2, null, true);
  d(54, T.PROBLEM, 'ポイント②の解説', '', 'GEN', '', 0, 'GEN', L.DIAGRAM, '図解6');
  d(55, T.PROBLEM, 'よくある課題', '', 'GEN', '', 0, 'GEN', L.CHALLENGE, null);
  d(56, T.PROBLEM, 'サービス表紙\nサービスを提供している理由', '', 'GEN', '', 0, 'GEN', L.SERVICE, 'モックアップ');
  d(57, T.STORY, '⒈ 等身大のスタート（原点）', 'キャリアスタート', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(58, T.STORY, '', 'きっかけ（原点）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(59, T.STORY, '', '小さな成功体験', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(60, T.STORY, '⒉ 挫折と誤った努力（苦労）', '間違った努力と失敗①', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(61, T.STORY, '', '間違った努力と失敗②', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(62, T.STORY, '', '間違った努力と失敗③', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(63, T.STORY, '', '間違った努力と失敗④', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(64, T.STORY, '⒊ 勝ちパターンとの出会い（転機）', '◯◯との出会い（見つける）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(65, T.STORY, '⒋ 検証から初期成果（小さな成功）', '検証過程（取り組んだこと）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(66, T.STORY, '', '検証過程（取り組んだこと）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(67, T.STORY, '', '初期成果', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(68, T.STORY, '⒌ 型化（再現性）', '成功体験の型化（取り組んだこと）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(69, T.STORY, '', '成功体験の型化（取り組んだこと）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(70, T.STORY, '', '成功体験の型化（取り組んだこと）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(71, T.STORY, '', '再現性（自分以外も成果が出た）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(72, T.STORY, '', 'サービス化（開発した）', 'GEN', '', 0, 'GEN', L.NARRATIVE, null);
  d(73, T.STORY, '⒍ 他社での成功と理念', '事例① Before', 'GEN', '', 0, 'GEN', L.CASE, '事例②（before）');
  d(74, T.STORY, '', '事例① After', 'GEN', '', 0, 'GEN', L.CASE, '事例②（after）');
  d(75, T.STORY, '', '事例② Before', 'GEN', '', 0, 'GEN', L.CASE, '事例③（before）');
  d(76, T.STORY, '', '事例② After', 'GEN', '', 0, 'GEN', L.CASE, '事例③（after）');
  d(77, T.STORY, '', '成果再現済み', 'GEN', '', 0, 'GEN', L.IMPACT, null);
  d(78, T.STORY, '', '理念（想い）', 'GEN', '', 0, 'GEN', L.RINEN, null);
  d(79, T.OFFER, 'サービス表紙', '', 'GEN', '', 0, 'GEN', L.SERVICE, 'モックアップ');
  d(80, T.OFFER, '特長①②③', '', 'GEN', '', 0, 'GEN', L.FEATURES, null, true);
  d(81, T.OFFER, 'サンプル①', '', 'GEN', '', 0, 'GEN', L.DIAGRAM40, '特徴①');
  d(82, T.OFFER, '特長①②③', '', 'REF', '', 80, 'GEN', L.FEATURES, null);
  d(83, T.OFFER, 'サンプル②', '', 'GEN', '', 0, 'GEN', L.DIAGRAM40, '特徴②');
  d(84, T.OFFER, '特長①②③', '', 'REF', '', 80, 'GEN', L.FEATURES, null);
  d(85, T.OFFER, 'サンプル③', '', 'GEN', '', 0, 'GEN', L.DIAGRAM40, '特徴③');
  d(86, T.OFFER, '利用イメージ（全体像）', '', 'GEN', '', 0, 'GEN', L.STEPS, null);
  d(87, T.OFFER, '工程①', '', 'FIX', '図解（工程①）', 0, 'GEN', L.KOTEI, '工程①', true);
  d(88, T.OFFER, '工程②', '', 'FIX', '図解（工程②）', 0, 'GEN', L.KOTEI, '工程②', true);
  d(89, T.OFFER, '工程③', '', 'FIX', '図解（工程③）', 0, 'GEN', L.KOTEI, '工程③', true);
  d(90, T.OFFER, '工程④', '', 'FIX', '図解（工程④）', 0, 'GEN', L.KOTEI, '工程④', true);
  d(91, T.OFFER, '成果実証済み', '', 'GEN', '', 0, 'GEN', L.IMPACT, null);
  d(92, T.OFFER, '開発費用と期間', '', 'GEN', '', 0, 'GEN', L.INVEST, null);
  d(93, T.OFFER, '理想①②', '', 'REF', '', 3, 'GEN', L.IDEAL, null);
  d(94, T.OFFER, '', '', 'REF', '', 4, 'GEN', L.IDEAL, null);
  d(95, T.OFFER, '価値ある？→ 二重線', '', 'FIX', 'No.92の金額に赤の二重線を引く。', 0, 'GEN', L.STRIKE, null);
  d(96, T.OFFER, '定価', '', 'GEN', '', 0, 'GEN', L.PRICE, null);
  d(97, T.OFFER, 'Zoom終了までなら', '', 'EMPTY', '', 0, 'FIX', L.S_ZOOM, null);
  d(98, T.OFFER, '特典⒈', '', 'GEN', '', 0, 'GEN', L.DIAGRAM40, '特典①');
  d(99, T.OFFER, '特典⒉', '', 'GEN', '', 0, 'GEN', L.DIAGRAM40, '特典②');
  d(100, T.OFFER, '理想③', '', 'GEN', '', 0, 'GEN', L.IDEAL, null);
  d(101, T.OFFER, '名言', '', 'EMPTY', '', 0, 'FIX', L.S_MEIGEN, null);
  d(102, T.OFFER, '値引き後の金額', '', 'GEN', '', 0, 'GEN', L.PRICE, null);
  d(103, T.OFFER, 'なぜこんな価格で？', '', 'GEN', '', 0, 'GEN', L.RINEN, null);
  d(104, T.OFFER, '分割払いも可', '', 'GEN', '', 0, 'GEN', L.TEXT55, null);
  d(105, T.OFFER, 'BYAF法', '', 'EMPTY', '', 0, 'FIX', L.S_BYAF, null);
  d(106, T.OFFER, '御礼', '', 'EMPTY', '', 0, 'FIX', L.S_OREI, null);
  return R;
}

/** 台本をAI生成する行のNo一覧（分割単位つき） */
function daihonGenRows_() {
  const defs = rowDefs_().filter(function (r) { return r.dm === 'GEN'; });
  return {
    partA: defs.filter(function (r) { return r.no <= 56; }).map(function (r) { return r.no; }),
    partB: defs.filter(function (r) { return r.no >= 57; }).map(function (r) { return r.no; })
  };
}

/** 構成テキストをAI生成する行のNo一覧 */
function kouseiGenRows_() {
  return rowDefs_().filter(function (r) { return r.km === 'GEN'; }).map(function (r) { return r.no; });
}

/** 構成テキスト中の図解タグを必須とする行 → タグ */
function requiredImgTags_() {
  const m = {};
  rowDefs_().forEach(function (r) {
    if (r.km === 'GEN' && r.img && r.img !== '*プロフ') m[r.no] = '図解（' + r.img + '）';
  });
  return m;
}

/** アイコン差し替え対象の行No一覧 */
function iconRows_() {
  return rowDefs_().filter(function (r) { return r.icon; }).map(function (r) { return r.no; });
}