/**
 * 30_prompts.gs（APIレス版）
 * ヒアリングシート読込と、手動実行用プロンプト（Googleドキュメント）の構築
 *
 * フロー: GASがヒアリング内容を埋め込んだプロンプトDocを自動生成
 *  → ユーザーがClaude（チャット/Claude Code）に貼って実行
 *  → 返ってきた2つのJSON（台本→構成テキスト）を構成シート「AI出力貼り付け」タブへ貼る
 */

// ============================================================
// ヒアリングシートの読込・テキスト化
// ============================================================

/** シート1枚をタブ区切りテキストへ（空行圧縮） */
function serializeSheet_(sheet) {
  const values = sheet.getDataRange().getValues();
  const lines = [];
  values.forEach(function (row) {
    const cells = row.map(function (c) { return String(c).trim(); }).filter(function (c) { return c !== ''; });
    if (cells.length > 0) lines.push(cells.join('\t'));
  });
  return lines.join('\n');
}

/** ヒアリングスプシ（3タブ）を読み込む。タブ名は前後空白を許容 */
function readHearing_(spreadsheetId) {
  const ss = SpreadsheetApp.openById(spreadsheetId);
  function findTab(name) {
    const hit = ss.getSheets().filter(function (s) { return s.getName().trim() === name.trim(); })[0];
    if (!hit) throw new Error('ヒアリングシートにタブが見つかりません: ' + name);
    return hit;
  }
  return {
    offer: serializeSheet_(findTab(HEARING_TABS.OFFER)),
    problem: serializeSheet_(findTab(HEARING_TABS.PROBLEM)),
    story: serializeSheet_(findTab(HEARING_TABS.STORY))
  };
}

// ============================================================
// プロンプト本体
// ============================================================

function rolePrompt_() {
  return [
    'あなたはウェビナー（オンラインセミナー）の構成作家です。',
    'クライアントへのヒアリング内容をもとに、決められた固定構造（No.1〜106）に沿ってウェビナーの原稿を作成します。',
    '',
    '# ウェビナーの全体構造（固定）',
    '- イントロ（No.1〜6）: 表紙 → 問いかけ → 理想①②③ → 講師紹介',
    '- 問題教育（No.7〜56）: お悩み提示 → モデル顧客の失敗ナラティブ → 旧ビリーフ（原因）→ 新ビリーフ（解決策）→ メリット3点 → 事例Before/After → よくある間違い → 正しいポイント2点 → サービス表紙',
    '- ストーリー（No.57〜78）: 講師自身の起業物語（原点 → 挫折 → 転機 → 検証 → 型化 → 他社成功と理念）',
    '- オファー（No.79〜106）: サービス詳細 → 実績 → 価格 → 特典 → クロージング',
    '',
    '# 絶対に守るルール',
    '1. 内容の創作をしない。すべての内容はヒアリング記入内容から導出すること。ヒアリングにない事実・エピソード・固有名詞を追加しない。',
    '2. 金額・社数・年数などの数値は、ヒアリングに記載された値だけを使用する。数値の変更・推定・創作は禁止。',
    '3. 文体変換と要約・分割は行ってよいが、意味を変えないこと。',
    '4. 一貫性ルール:',
    '   - 理想①②③（No.3〜5）＝ 新ビリーフのメリット3点（No.42〜44）を「もし、〜たら？」形式に変換したもの。',
    '   - お悩み①②③（No.8〜10）＝ 理想①②③の裏返し（現状の悩み）。',
    '   - 旧ビリーフ・新ビリーフはヒアリング記入値をそのまま核として使用。',
    '   - 理念（No.78）の中核フレーズを No.103 で再引用する。',
    '   - サービス概要文（サービス名＋一言説明）は No.56・79・96 で同一の文を使用する。'
  ].join('\n');
}

function daihonRulesPartA_() {
  return [
    '## イントロ',
    '- No.1: 挨拶＋自己紹介＋ウェビナータイトルの読み上げ。タイトルは「ターゲットの悩み＋理想状態」を組み合わせて生成（例:「社員20名を超えて現場対応に追われる社長の任せる組織づくり」）。',
    '- No.3〜5: 理想①②③。「もし、〜になったらどうでしょうか？」の問いかけ。メリット3点（ヒアリング⒊質問6）から逆算する。',
    '- No.6: 「その秘訣を本日シェアさせていただきます。」から始め、プロフィール（基本情報）を一人称で語り直し、「では、私の紹介は以上にして、具体的な中身に入っていこうと思います。」で締める。',
    '## 問題教育（ヒアリング【問題教育の記入用】から）',
    '- No.8〜10: お悩み①②③。「まず1つ目、〜」「続いて2つ目、〜」「最後3つ目、〜」で始め「というお悩みはありませんか。」＋「（挙手ありがとうございます。）」で締める。',
    '- No.11: モデル顧客の導入。「実は、このような3つの悩みを抱えていた、ある〇〇会社の経営者がいました。それが〇〇社長です。」',
    '- No.12〜13: ⒈質問1（以前の状況）を2文脈に分割。',
    '- No.14: ⒈質問2（課題のきっかけ）。',
    '- No.15〜16: ⒈質問3（一次課題）を2分割。',
    '- No.17〜19: ⒈質問4（二次課題）を「二次課題→連鎖→拡大」の3行に分割。',
    '- No.20〜21: ⒈質問5（経営リスクの認識）を「具体的リスク→本質的な恐れ」の2行に分割。',
    '- No.22: ⒈質問6（解決への決断）。「〜することを決意しました。」調。',
    '- No.23〜27: ⒉取り組み①を「内容(23)→エピソード(24,25)→結果=失敗(26,27)」の5行に分割。',
    '- No.28〜31: ⒉取り組み②を「内容(28)→エピソード(29,30)→結果=失敗(31)」の4行に分割。',
    '- No.32: ⒉質問7の言葉をカギ括弧の直接話法で。経営者の嘆き。',
    '- No.34: 「それは、（旧ビリーフ）だからです。」',
    '- No.35: ⒊質問2（旧ビリーフの定義）の説明。',
    '- No.36〜37: ⒊質問3（デメリット）を2行に分割。「この状態が続くと〜」「さらに〜」',
    '- No.39: 「（新ビリーフ）することです。」',
    '- No.40: ⒊質問5（新ビリーフの定義）。誤解の否定（「〜ではありません」）があれば含める。',
    '- No.41: 「そんな状態、（新ビリーフの動作）することで得られるメリットは3つあります。」',
    '- No.42〜44: メリット①②③。「まず1つ目は〜」「2つ目は〜」「最後3つ目は〜」',
    '- No.45: ⒊質問7のBeforeを「例えば、冒頭でお伝えした〇〇社長は、もともとは〜」で要約（モデル顧客の業種と社長名はNo.11と一致させる）。',
    '- No.46: Afterの要約＋「そんな事例があります。」で締める。',
    '- No.47: 「ただ、『（新ビリーフ）』を理解して実践し始めた経営者が、よく陥ってしまう間違いがあります。」',
    '- No.48: ⒋質問1〜2（よくある間違いの内容と定義）。「それが、（間違い）です。」から始める。',
    '- No.50: 「正しく（テーマの動作）するためのポイントは2つです。」',
    '- No.51: 「まず1つ目は、（ポイント①）です。」 No.52: ポイント①の解説（⒋質問4前半）。',
    '- No.53: 「2つ目は、（ポイント②）です。」 No.54: ポイント②の解説（⒋質問4後半）。',
    '- No.55: 「とはいえ、実際に取り組み始めると、次のような課題が出てきます。」＋自力実践の課題3点（ヒアリングから導出）＋「その解決策が（↓）」',
    '- No.56: 「『（サービス名）』です。」＋サービス概要文（オファー記入用の概要）。'
  ].join('\n');
}

function daihonRulesPartB_() {
  return [
    '## ストーリー（ヒアリング【ストーリーの記入用】から。講師の一人称で語る）',
    '- No.57〜59: ⒈の3記入欄（キャリアスタート／きっかけ（原点）／小さな成功体験）をそれぞれ1行に。',
    '- No.60〜63: ⒉の失敗①〜④をそれぞれ1行に。',
    '- No.64: ⒊転機（出会い）。',
    '- No.65〜66: ⒋検証過程①②。 No.67: ⒋初期成果。',
    '- No.68〜70: ⒌型化①〜③。 No.71: ⒌再現性。 No.72: ⒌サービス化。「それが（サービス名）」に繋がる形。',
    '- No.73〜74: ⒍事例① Before/After。「ここからは、実際に導入した企業の事例をご紹介します。」等の導入から。Afterは「そんな事例があります。」で締める。',
    '- No.75〜76: ⒍事例② Before/After。「他には、〜」から。Afterは「そんな事例もあります。」で締める。',
    '- No.77: ⒍成果再現済み（導入実績数はヒアリング値のみ）。',
    '- No.78: ⒍理念（想い）。中核フレーズをカギ括弧で明示する。',
    '## オファー（ヒアリング【オファー記入用】から）',
    '- No.79: 「それが『（サービス名）』です。」＋サービス概要文（No.56と同一の概要文を使用）。',
    '- No.80: 「（サービス名）には、大きく3つの特徴があります。」＋特徴3点を順に一言ずつ紹介。',
    '- No.81: 「まず1つ目の特徴は、〜です。」＋特徴①の詳細（質問2）。',
    '- No.82: 「2つ目の特徴は、〜です。」（1文のみ）。',
    '- No.83: 特徴②の詳細（質問3）。',
    '- No.84: 「最後の特徴は、〜です。」（1文のみ）。',
    '- No.85: 特徴③の詳細（質問4）。',
    '- No.86: 「そんな（サービス名）は、大きく4つのステップで進めていきます。」＋工程①〜④の列挙＋「それでは、それぞれ詳しくご紹介します。」',
    '- No.87〜90: 各工程の詳細説明（提供プロセスの質問2〜5）。「まず最初に行うのが〜」「続いて行うのが〜」等。',
    '- No.91: 導入実績（料金体系の質問1の値のみ）。',
    '- No.92: 「この（サービス名）を開発するまでに、約〇年の期間をかけ、開発費用は約〇〇円を投資しました。このくらいの時間と費用をかけても、」（ヒアリング値のみ）。',
    '- No.93〜94: 理想①②の再掲。No.93の冒頭は No.92 の「このくらいの時間と費用をかけても、」から自然に続く問いかけにする。',
    '- No.95: 「〇〇円の価値はあるでしょうか。しかし、（サービス名）は〇〇円ではありません。」（〇〇=No.92の投資額）。',
    '- No.96: 定価の提示（料金体系の質問4。複数プランがあれば全て）。',
    '- No.98: 特典1の紹介（料金体系の質問6）。 No.99: 特典2の紹介。**特典が1つしかない場合は台本・構成テキストとも空文字 "" を出力**（スライドは斜線=スキップ扱いになる）。',
    '- No.100: 理想③を「30日後、〜状態になったら、空いた時間で何に挑戦しますか？」形式に。',
    '- No.102: ウェビナー特別価格の提示（質問5）。「本日Zoom終了までなら〜」',
    '- No.103: 「なぜこんな価格でご提供しているのかと申しますと〜」＋理念（No.78の中核フレーズ）を理由として引用。',
    '- No.104: 分割払い案。定価から計算できる場合のみ（例: 24回払いで月々〇円）。計算できない料金体系（月額制など）なら台本・構成テキストとも空文字 "" を出力（スライドは斜線=スキップ扱い）。'
  ].join('\n');
}

function kouseiRules_() {
  const tags = requiredImgTags_();
  const spec = kouseiSpec_();
  // 行別の書式・字数規定（00_config.gs kouseiSpec_ が単一ソース）
  const nos = kouseiGenRows_();
  const grouped = {}; // fmt文 → no配列（同一規定をまとめて提示）
  nos.forEach(function (no) {
    const s = spec[no];
    if (!s) return;
    (grouped[s.fmt] = grouped[s.fmt] || []).push(no);
  });
  const ruleLines = Object.keys(grouped).map(function (fmt) {
    return '- No.' + grouped[fmt].join(',') + ': ' + fmt;
  });
  const tagLines = nos.filter(function (no) { return tags[no]; })
    .map(function (no) { return '- No.' + no + ': 末尾に「' + tags[no] + '」を必ず含める'; });
  return [
    '# 構成テキストの文体・書式（サンプル実測に基づく厳守ルール）',
    '- スライド見出しコピー。その行の台本の要点を圧縮したもの。台本にない内容を足さない。',
    '- 各行の書式と字数制限は以下のとおり。制限を超える場合は言い換えて短くすること。',
    ruleLines.join('\n'),
    '',
    '# 図解タグ（必須）',
    tagLines.join('\n')
  ].join('\n');
}

/** アイコン・背景の選定ルール（4フォルダのファイル名一覧を埋め込む） */
function designRules_(lists) {
  const t = designTargets_();
  const has = lists.iconP.length + lists.iconW.length + lists.bg.length + lists.select.length > 0;
  if (!has) return '';
  const parts = ['## 段階3: アイコン・背景の選定',
    '各行の内容・雰囲気に最も合う素材ファイルを一覧から選ぶ。ぴったりのものが無ければ空文字 ""。'];
  if (lists.iconP.length > 0) {
    parts.push('',
      '### アイコン（紫）: 対象行 ' + t.iconPurple.join(','),
      '- No.42-44=各メリットの内容、No.51/53=各ポイントの内容、No.87-90=各工程の作業内容を象徴するアイコンを1つずつ（icon欄）。',
      '- 一覧: ' + lists.iconP.join(' / '));
  }
  if (lists.iconW.length > 0) {
    parts.push('',
      '### アイコン（白）: 対象行 80 のみ',
      '- 特徴①②③それぞれに合うアイコンを3つ選び、icon欄に「名1／名2／名3」の全角スラッシュ区切りで出力（No.82/84へは自動再掲）。',
      '- 一覧: ' + lists.iconW.join(' / '));
  }
  if (lists.bg.length > 0) {
    parts.push('',
      '### 背景画像: 対象行 ' + t.bg.join(','),
      '- 行の感情トーン（理想=期待感、悩み・失敗=重さ、転機以降=前向き）に合わせて選び、bg欄に出力。同じ背景の連続使用可。',
      '- 一覧: ' + lists.bg.join(' / '));
  }
  if (lists.select.length > 0) {
    parts.push('',
      '### 選択画像: 対象行 72 のみ（bg欄）',
      '- 一覧: ' + lists.select.join(' / '));
  }
  parts.push('',
    '【出力3: デザインJSON】対象行のみでよい',
    '```json',
    '[{"no": 3, "icon": "", "bg": "ファイル名"}, {"no": 42, "icon": "ファイル名", "bg": ""}, ...]',
    '```');
  return parts.join('\n');
}

/** 用途キーのフォルダ内 画像ファイル名一覧 */
function scanAssetNames_(cfg, key) {
  const names = [];
  const folder = resolveNamedFolder_(cfg, key); // 50_slides.gs
  if (!folder) return names;
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    if (f.getMimeType().indexOf('image/') === 0) names.push(f.getName());
  }
  return names.sort();
}

/**
 * 手動実行用プロンプト全文を組み立てる（プロンプトDocの中身）
 */
function buildManualPrompt_(hearing, assetLists) {
  const gen = daihonGenRows_();
  const allDaihonNos = gen.partA.concat(gen.partB);
  const kouseiNos = kouseiGenRows_();
  const design = designRules_(assetLists || { iconP: [], iconW: [], bg: [], select: [] });
  const blocks = [
    rolePrompt_(),
    '',
    '━━━━━━━━━━━━━━━━━━━━━━━━━━',
    '# ヒアリング【オファー記入用】',
    hearing.offer,
    '',
    '# ヒアリング【問題教育の記入用】',
    hearing.problem,
    '',
    '# ヒアリング【ストーリーの記入用】',
    hearing.story,
    '━━━━━━━━━━━━━━━━━━━━━━━━━━',
    '',
    '# あなたのタスク（' + (design ? '3' : '2') + '段階）',
    '',
    '## 段階1: 台本の作成',
    '講師が話すスピーカーノート「台本」を作成する。',
    '- 文体: 「です・ます」の語り口調。聞き手（経営者）に語りかける自然な話し言葉。1行（=スライド1枚）あたり1〜4文。',
    '- 生成対象行: ' + allDaihonNos.join(','),
    '',
    '### 行別ルール（No.1〜56）',
    daihonRulesPartA_(),
    '',
    '### 行別ルール（No.57〜106）',
    daihonRulesPartB_(),
    '',
    '## 段階2: 構成テキストの作成',
    '段階1で作成した台本を圧縮し、各スライドに表示する「構成テキスト」を作成する。',
    '- 生成対象行: ' + kouseiNos.join(','),
    '',
    kouseiRules_()
  ];
  if (design) blocks.push('', design);
  blocks.push(
    '',
    '# 出力形式（厳守）',
    '出力は次の' + (design ? '3' : '2') + 'つのJSONコードブロックのみ。前置き・解説は不要。',
    '',
    '【出力1: 台本JSON】',
    '```json',
    '[{"no": 1, "daihon": "..."}, {"no": 3, "daihon": "..."}, ...]',
    '```',
    '',
    '【出力2: 構成テキストJSON】',
    '```json',
    '[{"no": 3, "kousei_text": "..."}, ...]',
    '```',
    design ? '（デザインJSONは段階3の指示どおり【出力3】として出力）' : '',
    '',
    '- 応答が長くなり分割出力する場合は、同じ配列の続きから出力すること（新しい「[」を開いてよい。取り込み側で連結される）。',
    '- 全行が揃うまで出力すること。省略・要約での置き換え（「以下同様」等）は禁止。');
  return blocks.join('\n');
}

/** 素材ルート直下サブフォルダの画像ファイル名一覧 */
function scanAssetNames_(cfg, subName) {
  const names = [];
  try {
    const it = DriveApp.getFolderById(cfg.ASSETS_FOLDER_ID).getFoldersByName(subName);
    if (!it.hasNext()) return names;
    const files = it.next().getFiles();
    while (files.hasNext()) {
      const f = files.next();
      if (f.getMimeType().indexOf('image/') === 0) names.push(f.getName());
    }
  } catch (e) { /* 一覧なしで続行 */ }
  return names.sort();
}

/**
 * プロンプトDoc（Googleドキュメント）を作成する
 * @return {Document}
 */
function createPromptDoc_(projectName, hearingId) {
  const cfg = getConfig_();
  const hearing = readHearing_(hearingId);
  const assetLists = {
    iconP: scanAssetNames_(cfg, 'ICON_P'),
    iconW: scanAssetNames_(cfg, 'ICON_W'),
    bg: scanAssetNames_(cfg, 'BG'),
    select: scanAssetNames_(cfg, 'SELECT')
  };
  const doc = DocumentApp.create('【プロンプト】' + projectName);
  doc.getBody().setText(buildManualPrompt_(hearing, assetLists));
  doc.saveAndClose();
  DriveApp.getFileById(doc.getId()).moveTo(DriveApp.getFolderById(cfg.OUTPUT_FOLDER_ID));
  return doc;
}